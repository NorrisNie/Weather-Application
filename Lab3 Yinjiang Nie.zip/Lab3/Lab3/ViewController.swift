//
//  ViewController.swift
//  Lab3
//
//  Created by Yinjiang Nie on 2022-11-17.
//

import UIKit
import CoreLocation
class ViewController: UIViewController, UITextFieldDelegate,  CLLocationManagerDelegate {
    
    @IBOutlet weak var textField: UITextField!
    
    @IBOutlet weak var weatherCondition: UIImageView!
    @IBOutlet weak var temp: UILabel!
    @IBOutlet weak var `switch`: UISwitch!
    @IBOutlet weak var location: UILabel!
    @IBOutlet weak var background: UIImageView!
    let locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view()
        
        self.textField.delegate = self
        
        
        locationManager.requestAlwaysAuthorization()
                locationManager.requestWhenInUseAuthorization()
                if CLLocationManager.locationServicesEnabled() {
                    locationManager.delegate = self
                    locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
                    locationManager.startUpdatingLocation()
                }
        
    }
    
    
    func fetchCityAndCountry(from location: CLLocation, completion: @escaping (_ city: String?, _ country:  String?, _ error: Error?) -> ()) {
        CLGeocoder().reverseGeocodeLocation(location) { placemarks, error in
            completion(placemarks?.first?.locality,
                       placemarks?.first?.country,
                       error)
        }
    }
    
        func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
            guard let location: CLLocation = manager.location else { return }
            fetchCityAndCountry(from: location){
                
                city, country, error in guard let city = city, let country = country, error == nil else { return }
                print(city + ", " + country)
                self.loadWeather(search: self.textField.text)
                self.textField.text = "\(city) \(country)"

            }
        }

 
   
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        textField.resignFirstResponder()
        performAction()
        return true
    }
    
    func performAction() {
        loadWeather(search: textField.text)
    }
    
    private func view() {
        let config = UIImage.SymbolConfiguration(paletteColors: [.systemRed, .systemBlue, .systemYellow])
        weatherCondition.preferredSymbolConfiguration = config
        
        
        weatherCondition.image = UIImage(systemName: "thermometer.medium")
    }
    
    
    @IBAction func searchBtn(_ sender: UIButton) {
        loadWeather(search: textField.text)
    }
    

    @IBAction func LocationBtn(_ sender: UIButton ) {
        loadWeather(search: textField.text)
//        I try to grab the city and country from the function location manger but still notwork
//        self.loadWeather(search: self.textField.text)
//        self.textField.text = "\(city) \(country)"

        }
        
        
        
        @IBAction func switchTemp(_ sender: UISwitch) {
            if sender.isOn{
                loadWeather(search: textField.text)
            }
            else{
                loadWeatherf(search: textField.text)
            }
            
        }
    
    
    
    private func loadWeather(search:String?){
        guard let search = search else{
            return
        }
        guard let url = getURL(query: search) else {
            print("could not get URL")
            return
        }
        
        let session = URLSession.shared
        
        let dataTask = session.dataTask(with: url){data, response, error in
            print("Network call complete")
            guard error == nil else {
                print("Reveived error")
                return
            }
            guard let data = data else {
                print("No data found")
                return
            }
            
            if let weatherResponse = self.parseJson(data: data){
                print(weatherResponse.location.name)
                print(weatherResponse.current.temp_c)
                print(weatherResponse.current.condition.text)
             
                
                DispatchQueue.main.async {
                    self.location.text = "\(weatherResponse.location.name): \(weatherResponse.current.condition.text)"
                    self.temp.text = "\(weatherResponse.current.temp_c)℃"
                    
                    switch(weatherResponse.current.condition.code){
                    case 1000 :
                        self.weatherCondition.image = UIImage(systemName: "sun.max")
                        break
                    case 1003 :
                        self.weatherCondition.image = UIImage(systemName: "cloud")
                        break
                    case 1006 :
                        self.weatherCondition.image = UIImage(systemName: "cloud")
                        break
                    case 1009 :
                        self.weatherCondition.image = UIImage(systemName: "sun.haze.fill")
                        break
                    case 1030 :
                        self.weatherCondition.image = UIImage(systemName: "sun.haze.fill")
                        break
                    case 1063 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1066 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.snow")
                        break
                    case 1069 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.sleet")
                        break
                    case 1072 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.sleet")
                        break
                    case 1087 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.bolt")
                        break
                    case 1114 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.snow")
                        break
                    case 1117 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.snow")
                        break
                    case 1135 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.fog")
                        break
                    case 1147 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.fog")
                        break
                    case 1150 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.drizzle")
                        break
                    case 1153 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.drizzle")
                        break
                    case 1168 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.drizzle")
                        break
                    case 1171 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.drizzle")
                        break
                    case 1180 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1183 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1186 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1189 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1192 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1195 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1198 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1201 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.sleet")
                        break
                    case 1204 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.sleet")
                        break
                    case 1207 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.sleet")
                        break
                    case 1210 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.snow")
                        break
                    case 1213 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.snow")
                        break
                    case 1216 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.snow")
                        break
                    case 1219 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.snow")
                        break
                    case 1222 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.snow")
                        break
                    case 1225 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.snow")
                        break
                    case 1237 :
                        self.weatherCondition.image = UIImage(systemName: "snowflake")
                        break
                    case 1240:
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1243 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1246:
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1249 :
                        self.weatherCondition.image = UIImage(systemName: "snowflake")
                        break
                    case 1252 :
                        self.weatherCondition.image = UIImage(systemName: "snowflake")
                        break
                    case 1255:
                        self.weatherCondition.image = UIImage(systemName: "snowflake")
                        break
                    case 1258 :
                        self.weatherCondition.image = UIImage(systemName: "snowflake")
                        break
                    case 1261 :
                        self.weatherCondition.image = UIImage(systemName: "snowflake")
                        break
                    case 1264 :
                        self.weatherCondition.image = UIImage(systemName: "snowflake")
                        break
                    case 1273 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1276 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1279 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1282 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    default:
                        print("issue")
                    }
                    
                }
                
               
            }
            
        }
        dataTask.resume()
    }
    
    
    
    private func loadWeatherf(search:String?){
        guard let search = search else{
            return
        }
        guard let url = getURL(query: search) else {
            print("could not get URL")
            return
        }
        
        let session = URLSession.shared
        
        let dataTask = session.dataTask(with: url){data, response, error in
            print("Network call complete")
            guard error == nil else {
                print("Reveived error")
                return
            }
            guard let data = data else {
                print("No data found")
                return
            }
            
            if let weatherResponse = self.parseJson(data: data){
                print(weatherResponse.location.name)
                print(weatherResponse.current.temp_f)
                print(weatherResponse.current.condition.text)
                
                
                DispatchQueue.main.async {
                    self.location.text = "\(weatherResponse.location.name): \(weatherResponse.current.condition.text)"
                    self.temp.text = "\(weatherResponse.current.temp_f)°F"
                    switch(weatherResponse.current.condition.code){
                    case 1000 :
                        self.weatherCondition.image = UIImage(systemName: "sun.max")
                        break
                    case 1003 :
                        self.weatherCondition.image = UIImage(systemName: "cloud")
                        break
                    case 1006 :
                        self.weatherCondition.image = UIImage(systemName: "cloud")
                        break
                    case 1009 :
                        self.weatherCondition.image = UIImage(systemName: "sun.haze.fill")
                        break
                    case 1030 :
                        self.weatherCondition.image = UIImage(systemName: "sun.haze.fill")
                        break
                    case 1063 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1066 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.snow")
                        break
                    case 1069 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.sleet")
                        break
                    case 1072 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.sleet")
                        break
                    case 1087 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.bolt")
                        break
                    case 1114 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.snow")
                        break
                    case 1117 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.snow")
                        break
                    case 1135 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.fog")
                        break
                    case 1147 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.fog")
                        break
                    case 1150 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.drizzle")
                        break
                    case 1153 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.drizzle")
                        break
                    case 1168 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.drizzle")
                        break
                    case 1171 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.drizzle")
                        break
                    case 1180 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1183 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1186 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1189 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1192 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1195 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1198 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1201 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.sleet")
                        break
                    case 1204 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.sleet")
                        break
                    case 1207 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.sleet")
                        break
                    case 1210 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.snow")
                        break
                    case 1213 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.snow")
                        break
                    case 1216 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.snow")
                        break
                    case 1219 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.snow")
                        break
                    case 1222 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.snow")
                        break
                    case 1225 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.snow")
                        break
                    case 1237 :
                        self.weatherCondition.image = UIImage(systemName: "snowflake")
                        break
                    case 1240:
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1243 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1246:
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1249 :
                        self.weatherCondition.image = UIImage(systemName: "snowflake")
                        break
                    case 1252 :
                        self.weatherCondition.image = UIImage(systemName: "snowflake")
                        break
                    case 1255:
                        self.weatherCondition.image = UIImage(systemName: "snowflake")
                        break
                    case 1258 :
                        self.weatherCondition.image = UIImage(systemName: "snowflake")
                        break
                    case 1261 :
                        self.weatherCondition.image = UIImage(systemName: "snowflake")
                        break
                    case 1264 :
                        self.weatherCondition.image = UIImage(systemName: "snowflake")
                        break
                    case 1273 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1276 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1279 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    case 1282 :
                        self.weatherCondition.image = UIImage(systemName: "cloud.rain")
                        break
                    default:
                        print("issue")
                    }
                   
                }
                
               
            }
            
        }
        dataTask.resume()
    }
    
    
    
    
    private func getURL(query:String) -> URL?{
        let baseUrl = "https://api.weatherapi.com/v1/"
        let currentEndpoint = "current.json"
        let apiKey = "9dbd97ef8ab84eaf814234649222011"
    
        guard let url = "\(baseUrl)\(currentEndpoint)?key=\(apiKey)&q=\(query)".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else{
            return nil
        }
        
        return URL(string: url)
    }
    
    
    private func parseJson(data: Data) -> WeatherResponse? {
        let decoder = JSONDecoder()
        var weather: WeatherResponse?
        do {
            weather = try decoder.decode(WeatherResponse.self, from: data)
        } catch {
        print("Error Decoding")
        }
        return weather
    }
}

struct WeatherResponse: Decodable{
    let location: Location
    let current: Weather
    
    
}
struct Location:Decodable{
    let name: String

}
struct Weather:Decodable{
    let temp_c: Float
    let temp_f: Float
    let condition: WeatherCondition
}
struct WeatherCondition:Decodable{
    let text: String
    let code: Int
}
   
